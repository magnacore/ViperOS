/*
 * Copyright (c) 1998 by Sun Microsystems, Inc.
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

package com.sun.jimi.core;

import java.awt.image.*;
import java.io.File;
import java.io.IOException;

import com.sun.jimi.util.RandomAccessStorage;
import com.sun.jimi.util.FileRandomAccessStorage;
import com.sun.jimi.core.raster.*;

/**
 * JimiImageFactory implementation for VMM based images.
 *
 * @author  Luke Gorrie
 * @version $Revision: 1.3 $ $Date: 1999/04/07 15:09:19 $
 */
public class VMemJimiImageFactory implements JimiImageFactory
{
	protected static long id;
	/** Memory factory to use when image sizes are below the VMM kick-in threshold */
	protected JimiImageFactory memoryFactory = new MemoryJimiImageFactory();

	public VMemJimiImageFactory()
	{
	}

	public IntRasterImage createIntRasterImage(int w, int h, ColorModel cm)
	{
		boolean bInMemoryError = false;
		try {
			if ((long) w * h * 4 < VMMControl.threshold) {
				System.out.println ("*** Trying in Memory Image because: " + ((long) w * h * 4) + " bytes, is less than " + VMMControl.threshold + ".");
				IntRasterImage iri = memoryFactory.createIntRasterImage(w, h, cm);
				if (!iri.isError())
				{
					return iri;
				}
				bInMemoryError = true;
				System.out.println ("*** Exception creating in memory image.  Trying VMem instead. 1.");
			}
		}
		catch (Error e) {
			System.out.println ("*** Error creating in memory image.  Trying VMem instead.");
			bInMemoryError = true;
		} catch (JimiException e) {
			System.out.println ("*** Exception creating in memory image.  Trying VMem instead. 2.");
			bInMemoryError = true;
		}
		
		try {
			if (bInMemoryError)
			{
				System.out.println ("*** Using Virtual Memory because there was an error using real memory.");
			}
			else
			{
				System.out.println ("*** Using Virtual Memory for Image because: " + ((long) w * h * 4) + " bytes, is more than " + VMMControl.threshold + " bytes.");
			}
			return new VMemIntRasterImage(createNextStorage(VMMControl.getDirectory()), w, h, cm);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public ByteRasterImage createByteRasterImage(int w, int h, ColorModel cm)
	{
		try {
			if ((long) w * (long) h < VMMControl.threshold) {
				ByteRasterImage bri = memoryFactory.createByteRasterImage(w, h, cm);
				if (!bri.isError())
				{
					return bri;
				}
				System.out.println ("*** Error creating in memory image of " + ((long) w * h) + " bytes, which is less than " + VMMControl.threshold + ".  Trying VMem instead.");
			}
		}
		catch (Exception e) {
			System.out.println ("*** Error creating in memory image of " + ((long) w * h) + " bytes, which is less than " + VMMControl.threshold + ".  Trying VMem instead.");
		}
		
		try {
			return new VMemByteRasterImage(createNextStorage(VMMControl.getDirectory()), w, h, cm);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public BitRasterImage createBitRasterImage(int w, int h, ColorModel cm)
	{
		try {
			if ((long) w * (long) h / (long) 8 < VMMControl.threshold) {
				BitRasterImage bri = memoryFactory.createBitRasterImage(w, h, cm);
				if (!bri.isError())
				{
					return bri;
				}
				System.out.println ("*** Error creating in memory image of " + ((long) w * h / 8) + " bytes, which is less than " + VMMControl.threshold + ".  Trying VMem instead.");
			}
		}
		catch (Exception e) {
			System.out.println ("*** Error creating in memory image of " + ((long) w * h / 8) + " bytes, which is less than " + VMMControl.threshold + ".  Trying VMem instead.");
		}

		try {
			int color0 = cm.getRGB(0);
			int color1 = cm.getRGB(1);
			byte[] alphas = new byte[] { (byte)((color0 >> 24) & 0xff), (byte)((color1 >> 24) & 0xff) };
			byte[] reds   = new byte[] { (byte)((color0 >> 16) & 0xff), (byte)((color1 >> 16) & 0xff) };
			byte[] greens = new byte[] { (byte)((color0 >>  8) & 0xff), (byte)((color1 >>  8) & 0xff) };
			byte[] blues  = new byte[] { (byte)((color0 >>  0) & 0xff), (byte)((color1 >>  0) & 0xff) };
			cm = new IndexColorModel(8, 2, reds, greens, blues, alphas);
			return (BitRasterImage)createByteRasterImage(w, h, cm);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public ChanneledIntRasterImage createChanneledIntRasterImage(int w, int h, ColorModel cm)
	{
		try {
			if (w * h * 4 < VMMControl.threshold) {
				ChanneledIntRasterImage ciri = memoryFactory.createChanneledIntRasterImage(w, h, cm);
				if (!ciri.isError())
				{
					return ciri;
				}
				System.out.println ("*** Error creating in memory image of " + ((long) w * h * 4) + " bytes, which is less than " + VMMControl.threshold + ".  Trying VMem instead.");
			}
		}
		catch (Exception e) {
			System.out.println ("*** Error creating in memory image of " + ((long) w * h * 4) + " bytes, which is less than " + VMMControl.threshold + ".  Trying VMem instead.");
			e.printStackTrace();
		}

		try {
			return new VMemChanneledIntRasterImage(createNextStorage(VMMControl.getDirectory()), w, h, cm);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	protected static synchronized RandomAccessStorage createNextStorage(File directory)
		throws IOException
	{
		File file = null;
		// find a swap-file, deleting any that are stale
		do {
			id++;
			String filename = directory + "/" + "jimidat." + id;
			file = new File(filename);
		}
		while (file.exists() && (!file.delete()));
		RandomAccessStorage storage = new FileRandomAccessStorage(file);
		return storage;
	}
}

