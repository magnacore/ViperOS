*********************************
* README_fr_FR			*
*********************************

Dictionnaire MySpell fr_FR :
----------------------------

La premi�re version du dictionnaire MySpell pour OpenOffice.org � �t� cr�e 
automatiquement � partir de la convertion du fichier affix et des listes 
de mots cr��s par Christophe Pythoud pour Ispell
Ces fichiers ont �t� publi�s dans la version 1.0.1 de Fran�ais-GUTenberg et
sont soumis par la licence GPL version 2. Pour cette raison le dictionnaire 
MySpell est lui aussi soumis � cette licence

Historique :
------------

version 1.0.1
Version corrig�e de la liste de mots avec regroupement des mots �quivalents afin 
de supprimer des fautes lors de la correction (les mots sont consid�r�s comme faux
si ils existent � double dans la liste de mots)

version 1.0.0
Version du dictionnaire MySpell fr_FR g�n�r�e automatiquement depuis � partir de la
convertion du fichier affix et des listes de mots cr��s par Christophe Pythoud pour
Ispell

*********************************
* Licence LGPL			*
*********************************


Introduction
------------

This is an unofficial translation of the GNU General Public License into
French. It was not published by the Free Software Foundation, and does not
legally state the distribution terms for software that uses the GNU
GPL--only the original English text of the GNU GPL does that. However, we
hope that this translation will help French speakers understand the GNU GPL
better.

Voici une adaptation non officielle de la Licence Publique G�n�rale du
projet GNU. Elle n'a pas �t� publi�e par la Free Software Foundation et son
contenu n'a aucune port�e l�gale car seule la version anglaise de ce
document d�taille le mode de distribution des logiciels sous GNU GPL. Nous
esp�rons cependant qu'elle permettra aux francophones de mieux comprendre la
GPL.


Licence Publique G�n�rale GNU Version 2, Juin 1991
--------------------------------------------------

Copyright � Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA 02111-1307
�tats-Unis, 1989, 1991.
La copie et la distribution de copies exactes de ce document sont
autoris�es, mais aucune modification n'est permise.


Pr�ambule
---------

Les licences d'utilisation de la plupart des programmes sont d�finies pour
limiter ou supprimer toute libert� � l'utilisateur. � l'inverse, la Licence
Publique G�n�rale (General Public License) est destin�e � vous garantir la
libert� de partager et de modifier les logiciels libres, et de s'assurer que
ces logiciels sont effectivement accessibles � tout utilisateur.

Cette Licence Publique G�n�rale s'applique � la plupart des programmes de la
Free Software Foundation, comme � tout autre programme dont l'auteur l'aura
d�cid� (d'autres logiciels de la FSF sont couverts pour leur part par la
Licence Publique G�n�rale pour Biblioth�ques GNU (LGPL)). Vous pouvez aussi
appliquer les termes de cette Licence � vos propres programmes, si vous le
d�sirez.

Libert� des logiciels ne signifie pas n�cessairement gratuit�. Notre Licence
est con�ue pour vous assurer la libert� de distribuer des copies des
programmes, gratuitement ou non, de recevoir le code source ou de pouvoir
l'obtenir, de modifier les programmes ou d'en utiliser des �l�ments dans de
nouveaux programmes libres, en sachant que vous y �tes autoris�.

Afin de garantir ces droits, nous avons d� introduire des restrictions
interdisant � quiconque de vous les refuser ou de vous demander d'y
renoncer. Ces restrictions vous imposent en retour certaines obligations si
vous distribuez ou modifiez des copies de programmes prot�g�s par la
Licence. En d'autre termes, il vous incombera en ce cas de :

   * transmettre aux destinataires tous les droits que vous poss�dez,
   * exp�dier aux destinataires le code source ou bien tenir celui-ci � leur
     disposition,
   * leur remettre cette Licence afin qu'ils prennent connaissance de leurs
     droits.

Nous prot�geons vos droits de deux fa�ons : d'abord par le copyright du
logiciel, ensuite par la remise de cette Licence qui vous autorise
l�galement � copier, distribuer et/ou modifier le logiciel.

En outre, pour prot�ger chaque auteur ainsi que la FSF, nous affirmons
solennellement que le programme concern� ne fait l'objet d'aucune garantie.
Si un tiers le modifie puis le redistribue, tous ceux qui en recevront une
copie doivent savoir qu'il ne s'agit pas de l'original afin qu'une copie
d�fectueuse n'entache pas la r�putation de l'auteur du logiciel.

Enfin, tout programme libre est sans cesse menac� par des d�p�ts de brevets.
Nous souhaitons � tout prix �viter que des distributeurs puissent d�poser
des brevets sur les Logiciels Libres pour leur propre compte. Pour �viter
cela, nous stipulons bien que tout d�p�t �ventuel de brevet doit accorder
express�ment � tout un chacun le libre usage du produit.

Les dispositions pr�cises et les conditions de copie, de distribution et de
modification de nos logiciels sont les suivantes :

Stipulations et conditions relatives � la copie, la distribution et la
modification

  ------------------------------------------------------------------------

   * Article 0
     La pr�sente Licence s'applique � tout Programme (ou autre travail) o�
     figure une note, plac�e par le d�tenteur des droits, stipulant que
     ledit Programme ou travail peut �tre distribu� selon les termes de la
     pr�sente Licence. Le terme Programme d�signe aussi bien le Programme
     lui-m�me que tout travail qui en est d�riv� selon la loi, c'est-�-dire
     tout ouvrage reproduisant le Programme ou une partie de celui-ci, �
     l'identique ou bien modifi�, et/ou traduit dans une autre langue (la
     traduction est consid�r�e comme une modification). Chaque personne
     concern�e par la Licence Publique G�n�rale sera d�sign�e par le terme
     Vous.

     Les activit�s autres que copie, distribution et modification ne sont
     pas couvertes par la pr�sente Licence et sortent de son cadre. Rien ne
     restreint l'utilisation du Programme et les donn�es issues de celui-ci
     ne sont couvertes que si leur contenu constitue un travail bas� sur le
     logiciel (ind�pendemment du fait d'avoir �t� r�alis� en lan�ant le
     Programme). Tout d�pend de ce que le Programme est cens� produire.

     -----------------------------------------------------------------------
   * Article 1.
     Vous pouvez copier et distribuer des copies conformes du code source du
     Programme, tel que Vous l'avez re�u, sur n'importe quel support, �
     condition de placer sur chaque copie un copyright appropri� et une
     restriction de garantie, de ne pas modifier ou omettre toutes les
     stipulations se r�f�rant � la pr�sente Licence et � la limitation de
     garantie, et de fournir avec toute copie du Programme un exemplaire de
     la Licence.

     Vous pouvez demander une r�tribution financi�re pour la r�alisation de
     la copie et demeurez libre de proposer une garantie assur�e par vos
     soins, moyennant finances.

     -----------------------------------------------------------------------
   * Article 2.
     Vous pouvez modifier votre copie ou vos copies du Programme ou partie
     de celui-ci, ou d'un travail bas� sur ce Programme, et copier et
     distribuer ces modifications selon les termes de l'article 1, �
     condition de Vous conformer �galement aux conditions suivantes :
        o a) Ajouter aux fichiers modifi�s l'indication tr�s claire des
          modifications effectu�es, ainsi que la date de chaque changement.
        o b) Distribuer sous les termes de la Licence Publique G�n�rale
          l'ensemble de toute r�alisation contenant tout ou partie du
          Programme, avec ou sans modifications.
        o c) Si le Programme modifi� lit des commandes de mani�re
          interactive lors de son ex�cution, faire en sorte qu'il affiche,
          lors d'une invocation ordinaire, le copyright appropri� en
          indiquant clairement la limitation de garantie (ou la garantie que
          Vous Vous engagez � fournir Vous-m�me), qu'il stipule que tout
          utilisateur peut librement redistribuer le Programme selon les
          conditions de la Licence Publique G�n�rale GNU, et qu'il montre �
          tout utilisateur comment lire une copie de celle-ci (exception :
          si le Programme original est interactif mais n'affiche pas un tel
          message en temps normal, tout travail d�riv� de ce Programme ne
          sera pas non plus contraint de l'afficher).

     Toutes ces conditions s'appliquent � l'ensemble des modifications. Si
     des �l�ments identifiables de ce travail ne sont pas d�riv�s du
     Programme et peuvent �tre raisonnablement consid�r�s comme
     ind�pendants, la pr�sente Licence ne s'applique pas � ces �l�ments
     lorsque Vous les distribuez seuls. Mais, si Vous distribuez ces m�mes
     �l�ments comme partie d'un ensemble coh�rent dont le reste est bas� sur
     un Programme soumis � la Licence, ils lui sont �galement soumis, et la
     Licence s'�tend ainsi � l'ensemble du produit, quel qu'en soit
     l'auteur.

     Cet article n'a pas pour but de s'approprier ou de contester vos droits
     sur un travail enti�rement r�alis� par Vous, mais plut�t d'ouvrir droit
     � un contr�le de la libre distribution de tout travail d�riv� ou
     collectif bas� sur le Programme.

     En outre, toute fusion d'un autre travail, non bas� sur le Programme,
     avec le Programme (ou avec un travail d�riv� de ce dernier), effectu�e
     sur un support de stockage ou de distribution, ne fait pas tomber cet
     autre travail sous le contr�le de la Licence.

     -----------------------------------------------------------------------
   * Article 3.
     Vous pouvez copier et distribuer le Programme (ou tout travail d�riv�
     selon les conditions �nonc�es dans l'article 1) sous forme de code
     objet ou ex�cutable, selon les termes des articles 0 et 1, � condition
     de respecter les clauses suivantes :
        o a) Fournir le code source complet du Programme, sous une forme
          lisible par un ordinateur et selon les termes des articles 0 et 1,
          sur un support habituellement utilis� pour l'�change de donn�es ;
          ou,
        o b) Faire une offre �crite, valable pendant au moins trois ans,
          pr�voyant de donner � tout tiers qui en fera la demande une copie,
          sous forme lisible par un ordinateur, du code source
          correspondant, pour un tarif n'exc�dant pas le co�t de la copie,
          selon les termes des articles 0 et 1, sur un support couramment
          utilis� pour l'�change de donn�es informatiques ; ou,
        o c) Informer le destinataire de l'endroit o� le code source peut
          �tre obtenu (cette solution n'est recevable que dans le cas d'une
          distribution non commerciale, et uniquement si Vous avez re�u le
          Programme sous forme de code objet ou ex�cutable avec l'offre
          pr�vue � l'alin�a b ci-dessus).

     Le code source d'un travail d�signe la forme de cet ouvrage sous
     laquelle les modifications sont les plus ais�es. Sont ainsi d�sign�s la
     totalit� du code source de tous les modules composant un Programme
     ex�cutable, de m�me que tout fichier de d�finition associ�, ainsi que
     les scripts utilis�s pour effectuer la compilation et l'installation du
     Programme ex�cutable. Toutefois, l'environnement standard de
     d�veloppement du syst�me d'exploitation mis en oeuvre (source ou
     binaire) -- compilateurs, biblioth�ques, noyau, etc. -- constitue une
     exception, sauf si ces �l�ments sont diffus�s en m�me temps que le
     Programme ex�cutable.

     Si la distribution de l'ex�cutable ou du code objet consiste � offrir
     un acc�s permettant de copier le Programme depuis un endroit
     particulier, l'offre d'un acc�s �quivalent pour se procurer le code
     source au m�me endroit est consid�r� comme une distribution de ce code
     source, m�me si l'utilisateur choisit de ne pas profiter de cette
     offre.

     -----------------------------------------------------------------------
   * Article 4.
     Vous ne pouvez pas copier, modifier, c�der, d�poser ou distribuer le
     Programme d'une autre mani�re que l'autorise la Licence Publique
     G�n�rale. Toute tentative de ce type annule imm�diatement vos droits
     d'utilisation du Programme sous cette Licence. Toutefois, les tiers
     ayant re�u de Vous des copies du Programme ou le droit d'utiliser ces
     copies continueront � b�n�ficier de leur droit d'utilisation tant
     qu'ils respecteront pleinement les conditions de la Licence.

     -----------------------------------------------------------------------
   * Article 5.
     Ne l'ayant pas sign�e, Vous n'�tes pas oblig� d'accepter cette Licence.
     Cependant, rien d'autre ne Vous autorise � modifier ou distribuer le
     Programme ou quelque travaux d�riv�s : la loi l'interdit tant que Vous
     n'acceptez pas les termes de cette Licence. En cons�quence, en
     modifiant ou en distribuant le Programme (ou tout travail bas� sur
     lui), Vous acceptez implicitement tous les termes et conditions de
     cette Licence.

     -----------------------------------------------------------------------
   * Article 6.
     La diffusion d'un Programme (ou de tout travail d�riv�) suppose l'envoi
     simultan� d'une licence autorisant la copie, la distribution ou la
     modification du Programme, aux termes et conditions de la Licence. Vous
     n'avez pas le droit d'imposer de restrictions suppl�mentaires aux
     droits transmis au destinataire. Vous n'�tes pas responsable du respect
     de la Licence par un tiers.

     -----------------------------------------------------------------------
   * Article 7.
     Si, � la suite d'une d�cision de Justice, d'une plainte en contrefa�on
     ou pour toute autre raison (li�e ou non � la contrefa�on), des
     conditions Vous sont impos�es (que ce soit par ordonnance, accord
     amiable ou autre) qui se r�v�lent incompatibles avec les termes de la
     pr�sente Licence, Vous n'�tes pas pour autant d�gag� des obligations
     li�es � celle-ci : si Vous ne pouvez concilier vos obligations l�gales
     ou autres avec les conditions de cette Licence, Vous ne devez pas
     distribuer le Programme.

     Si une partie quelconque de cet article est invalid�e ou inapplicable
     pour quelque raison que ce soit, le reste de l'article continue de
     s'appliquer et l'int�gralit� de l'article s'appliquera en toute autre
     circonstance.

     Le pr�sent article n'a pas pour but de Vous pousser � enfreindre des
     droits ou des dispositions l�gales ni en contester la validit� ; son
     seul objectif est de prot�ger l'int�grit� du syst�me de distribution du
     Logiciel Libre. De nombreuses personnes ont g�n�reusement contribu� �
     la large gamme de Programmes distribu�e de cette fa�on en toute
     confiance ; il appartient � chaque auteur/donateur de d�cider de
     diffuser ses Programmes selon les crit�res de son choix.

     -----------------------------------------------------------------------
   * Article 8.
     Si la distribution et/ou l'utilisation du Programme est limit�e dans
     certains pays par des brevets ou des droits sur des interfaces, le
     d�tenteur original des droits qui place le Programme sous la Licence
     Publique G�n�rale peut ajouter explicitement une clause de limitation
     g�ographique excluant ces pays. Dans ce cas, cette clause devient une
     partie int�grante de la Licence.

     -----------------------------------------------------------------------
   * Article 9.
     La Free Software Foundation se r�serve le droit de publier
     p�riodiquement des mises � jour ou de nouvelles versions de la Licence.
     R�dig�es dans le m�me esprit que la pr�sente version, elles seront
     cependant susceptibles d'en modifier certains d�tails � mesure que de
     nouveaux probl�mes se font jour.

     Chaque version poss�de un num�ro distinct. Si le Programme pr�cise un
     num�ro de version de cette Licence et � toute version ult�rieure �,
     Vous avez le choix de suivre les termes et conditions de cette version
     ou de toute autre version plus r�cente publi�e par la Free Software
     Foundation. Si le Programme ne sp�cifie aucun num�ro de version, Vous
     pouvez alors choisir l'une quelconque des versions publi�es par la Free
     Software Foundation.

     -----------------------------------------------------------------------
   * Article 10.
     Si Vous d�sirez incorporer des �l�ments du Programme dans d'autres
     Programmes libres dont les conditions de distribution diff�rent, Vous
     devez �crire � l'auteur pour lui en demander la permission. Pour ce qui
     est des Programmes directement d�pos�s par la Free Software Foundation,
     �crivez-nous : une exception est toujours envisageable. Notre d�cision
     sera bas�e sur notre volont� de pr�server la libert� de notre Programme
     ou de ses d�riv�s et celle de promouvoir le partage et la r�utilisation
     du logiciel en g�n�ral.

                              LIMITATION DE GARANTIE
     -----------------------------------------------------------------------
   * Article 11.
     Parce que l'utilisation de ce Programme est libre et gratuite, aucune
     garantie n'est fournie, comme le permet la loi. Sauf mention �crite,
     les d�tenteurs du copyright et/ou les tiers fournissent le Programme en
     l'�tat, sans aucune sorte de garantie explicite ou implicite, y compris
     les garanties de commercialisation ou d'adaptation dans un but
     particulier. Vous assumez tous les risques quant � la qualit� et aux
     effets du Programme. Si le Programme est d�fectueux, Vous assumez le
     co�t de tous les services, corrections ou r�parations n�cessaires.

     -----------------------------------------------------------------------
   * Article 12.
     Sauf lorsqu'explicitement pr�vu par la Loi ou accept� par �crit, ni le
     d�tenteur des droits, ni quiconque autoris� � modifier et/ou
     redistribuer le Programme comme il est permis ci-dessus ne pourra �tre
     tenu pour responsable de tout dommage direct, indirect, secondaire ou
     accessoire (pertes financi�res dues au manque � gagner, �
     l'interruption d'activit�s ou � la perte de donn�es, etc., d�coulant de
     l'utilisation du Programme ou de l'impossibilit� d'utiliser celui-ci).

  ------------------------------------------------------------------------
                        FIN DES TERMES ET CONDITIONS


Comment appliquer ces directives � vos nouveaux programmes
----------------------------------------------------------

Si vous d�veloppez un nouveau programme et d�sirez en faire b�n�ficier tout
un chacun, la meilleure m�thode est d'en faire un Logiciel Libre que tout le
monde pourra redistribuer et modifier selon les termes de la Licence
Publique G�n�rale.

Pour cela, ins�rez les indications suivantes dans votre programme (il est
pr�f�rable et plus s�r de les faire figurer au d�but de chaque fichier
source ; dans tous les cas, chaque module source devra comporter au minimum
la ligne de � copyright � et indiquer o� r�sident toutes les autres
indications) :
  ------------------------------------------------------------------------
((une ligne pour donner le nom du programme et donner une id�e de sa
finalit�))
Copyright (C) 19xx ((nom de l'auteur))

Ce programme est libre, vous pouvez le redistribuer et/ou le modifier selon
les termes de la Licence Publique G�n�rale GNU publi�e par la Free Software
Foundation (version 2 ou bien toute autre version ult�rieure choisie par
vous).

Ce programme est distribu� car potentiellement utile, mais SANS AUCUNE
GARANTIE, ni explicite ni implicite, y compris les garanties de
commercialisation ou d'adaptation dans un but sp�cifique. Reportez-vous � la
Licence Publique G�n�rale GNU pour plus de d�tails.

Vous devez avoir re�u une copie de la Licence Publique G�n�rale GNU en m�me
temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307,
�tats-Unis.
  ------------------------------------------------------------------------

Ajoutez �galement votre adresse �lectronique, le cas �ch�ant, ainsi que
votre adresse postale.

Si le programme est interactif, faites-lui afficher un court avertissement
du type de celui-ci � chaque invocation :
  ------------------------------------------------------------------------
...(nom du programme) version 69, Copyright (C) 19aa nom de l'auteur

...(nom du programme) est fourni sans AUCUNE GARANTIE.
Pour plus de d�tails, tapez `g'.

Ce programme est libre et vous �tes encourag� � le redistribuer sous
certaines conditions ; tapez `c' pour plus de d�tails.
  ------------------------------------------------------------------------

Les commandes hypoth�tiques `g' et `c' doivent afficher les sections
appropri�es de la Licence Publique G�n�rale GNU. Bien entendu, vous pouvez
implanter ces commandes comme bon vous semble : options dans un menu, ou
bien accessibles d'un clic de souris, etc., tout d�pend de votre programme.

Si vous officiez en tant que programmeur, n'omettez pas de demander � votre
employeur, votre �tablissement scolaire ou autres de signer une d�charge
stipulant leur renoncement aux droits qu'ils pourraient avoir sur le
programme :
  ------------------------------------------------------------------------
...((employeur, �cole...)) d�clare par la pr�sente ne pas revendiquer de
droits sur le programme � (nom du programme) � r�alis� par ...((nom de
l'auteur)).
((signature du responsable)), ...((date)), ...((nom et qualit� du
responsable)).

La Licence Publique G�n�rale ne permet pas d'inclure votre programme dans
des logiciels sous licence commerciale sp�cifique. Si votre programme est
une fonction de biblioth�que, vous jugerez probablement plus judicieux de le
faire relever de la Licence G�n�rale de Biblioth�que GNU (LGPL) plut�t que
de la pr�sente.